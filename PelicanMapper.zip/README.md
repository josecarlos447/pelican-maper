# Pelican Mapper — protótipo Android
Projeto nativo Java, sem dependências de execução nem acesso à internet.

## Gerar e instalar APK
1. Instale Android Studio e abra esta pasta.
2. Use JDK 17, SDK Android 35 e Gradle 8.9 (o projeto não inclui Gradle Wrapper).
3. Sincronize e selecione Build > Generate App Bundles or APKs > Generate APKs.
   Alternativa com Gradle 8.9 instalado: gradle :app:assembleDebug
4. APK: app/build/outputs/apk/debug/app-debug.apk. Copie ao celular e abra para instalar.
   Via computador com ADB: adb install -r app/build/outputs/apk/debug/app-debug.apk

## Configurar
Conecte teclado/mouse por OTG ou Bluetooth. Abra o app e salve seu perfil.
Ative Pelican Mapper nas configurações de Acessibilidade, volte ao app e ative o mapeamento.
Abra o jogo. F8 pausa/retoma; desativar Acessibilidade também encerra a conversão.
Se Android bloquear a permissão de um app instalado por arquivo, confira a opção de configurações restritas nas informações do app.
Nenhuma permissão de root, ADB em execução, leitura do conteúdo da tela ou internet é usada.
O pacote padrão é com.dts.freefireth; para outros jogos, informe o pacote instalado.

## Configuração
Linhas TECLA,X%,Y%. Posições referem-se à tela inteira na orientação do jogo.
SPACE é espaço. MOUSE1/MOUSE2 são cliques. JOY é centro do direcional.
LOOK é início de cada arrasto de câmera. Ajuste ao seu HUD.
WASD faz arrastos curtos ao pressionar/repetir tecla, não joystick contínuo.
Teclas comuns e cliques fazem toque único, não toque mantido.
Mouse global requer Android 14+. Android 8–13: apenas teclado.
O cursor é absoluto e pode atingir a borda: não há captura relativa ilimitada.
Durante um gesto, novos comandos são descartados para evitar cancelamentos.
Não suporta andar, mirar e atirar simultaneamente: precisa de outro backend para uso competitivo.
Não inclui macros, mira automática nem alterações no jogo.

## Verificação pendente
Este projeto precisa ser compilado no Android Studio e testado em aparelho.
Roteiro: instalar; salvar perfil inválido e válido; ativar acessibilidade; testar F8;
confirmar que não injeta fora do pacote escolhido; testar teclas, mudança de orientação,
mouse Android 14+, pausa, desligar serviço e reconectar dispositivos.
Não foi validado com Free Fire; compatibilidade não garantida.

Referência: https://developer.android.com/reference/android/accessibilityservice/AccessibilityService
