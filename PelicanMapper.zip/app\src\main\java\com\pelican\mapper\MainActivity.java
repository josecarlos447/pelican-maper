package com.pelican.mapper;
import android.app.*;
import android.os.*;
import android.content.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.*;

public class MainActivity extends Activity {
 LinearLayout body; EditText pkg, maps, sensitivity; Switch mouse;
 void label(String s) { TextView t=new TextView(this); t.setText(s); t.setTextSize(16); t.setPadding(0,16,0,8); body.addView(t); }
 EditText field(String s, boolean multi) { EditText e=new EditText(this); e.setText(s); e.setSingleLine(!multi); body.addView(e); return e; }
 void button(String s, Runnable r) { Button b=new Button(this); b.setText(s); b.setOnClickListener(v->r.run()); body.addView(b); }
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  ScrollView scroll=new ScrollView(this); body=new LinearLayout(this); body.setOrientation(1); body.setPadding(28,48,28,48); scroll.addView(body); setContentView(scroll);
  android.content.SharedPreferences p=getSharedPreferences("mapper",0);
  label("PELICAN / MAPPER 0.1");
  label("Protótipo: teclas → toques; WASD → arrastos curtos. Mouse exige Android 14+. Sem multitouch contínuo. Conecte teclado/mouse por USB OTG ou Bluetooth.");
  label("1. Pacote do jogo (mapeamento só neste app)");
  pkg=field(p.getString("package","com.dts.freefireth"),false);
  label("2. Tecla, X%, Y% — uma por linha. Use SPACE, R, C, 1 etc. MOUSE1 e MOUSE2 para os cliques. WASD usa o ponto JOY.");
  maps=field(p.getString("maps","SPACE,90,75\nR,80,70\nC,85,85\n1,45,10\nMOUSE1,88,50\nMOUSE2,75,50\nJOY,18,75\nLOOK,65,45"),true);
  maps.setMinLines(9);
  label("3. Sensibilidade do mouse (0.1 a 5)");
  sensitivity=field(p.getString("sensitivity","1.0"),false);
  mouse=new Switch(this); mouse.setText("Converter mouse (Android 14+)"); mouse.setChecked(p.getBoolean("mouse",false)); body.addView(mouse);
  button("Salvar configuração",()->save());
  button("Abrir acessibilidade",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
  button("Ativar / pausar",()->{
   if(MapperService.instance==null) { Toast.makeText(this,"Ative Pelican Mapper em Acessibilidade primeiro.",1).show(); return; }
   if(save()) { MapperService.instance.toggle(); }
  });
  button("Abrir jogo",()->{
   Intent i=getPackageManager().getLaunchIntentForPackage(pkg.getText().toString().trim());
   if(i!=null) startActivity(i); else Toast.makeText(this,"Jogo não encontrado. Abra-o pelo launcher.",1).show();
  });
  label("F8 ativa/pausa. Volte aqui para ajustar as posições ao HUD do jogo. Coordenadas são porcentagens da tela inteira na orientação em que você joga. Clique de mouse gera toque único; movimento gera arrastos curtos, sem captura ilimitada do cursor.");
  label("Permissão: o serviço observa teclas e o pacote em primeiro plano e injeta gestos. Não há internet, leitura de texto, root ou alteração do jogo. Você pode desativá-lo nas configurações.");
 }
 boolean save() {
  try {
   String target=pkg.getText().toString().trim();
   if(!target.matches("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+") || target.equals(getPackageName())) throw new Exception("Pacote inválido");
   float sens=Float.parseFloat(sensitivity.getText().toString()); if(!Float.isFinite(sens)||sens<.1f||sens>5) throw new Exception("Sensibilidade: 0.1 a 5");
   String raw=maps.getText().toString(); MapperService.parse(raw);
   getSharedPreferences("mapper",0).edit().putString("package",target).putString("maps",raw).putString("sensitivity",Float.toString(sens)).putBoolean("mouse",mouse.isChecked()).apply();
   if(MapperService.instance!=null) MapperService.instance.reload();
   Toast.makeText(this,"Salvo",0).show(); return true;
  } catch(Exception e) { Toast.makeText(this,e.getMessage(),1).show(); return false; }
 }
}