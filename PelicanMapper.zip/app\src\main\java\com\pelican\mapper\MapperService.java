package com.pelican.mapper;
import android.accessibilityservice.*;
import android.content.*;
import android.graphics.Path;
import android.os.*;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;
import java.util.*;

public class MapperService extends AccessibilityService {
 static MapperService instance;
 Map<String,float[]> points=new HashMap<>();
 String target="", foreground=""; boolean enabled=false, mouse=false, busy=false;
 float sensitivity=1,lastX=Float.NaN,lastY=Float.NaN;
 int buttons=0;
 static Map<String,float[]> parse(String raw) throws Exception {
  Map<String,float[]> out=new HashMap<>();
  for(String row:raw.split("\\r?\\n")) {
   if(row.trim().isEmpty()) continue;
   String[] a=row.trim().toUpperCase(Locale.ROOT).split(",");
   if(a.length!=3) throw new Exception("Use TECLA,X%,Y%");
   String key=a[0].trim();
   if(!Arrays.asList("JOY","LOOK","MOUSE1","MOUSE2").contains(key) && KeyEvent.keyCodeFromString("KEYCODE_"+key)==KeyEvent.KEYCODE_UNKNOWN) throw new Exception("Tecla inválida: "+key);
   if(key.equals("F8")||Arrays.asList("W","A","S","D").contains(key)) throw new Exception("F8 e WASD são reservados");
   float x=Float.parseFloat(a[1].trim())/100, y=Float.parseFloat(a[2].trim())/100;
   if(!Float.isFinite(x)||!Float.isFinite(y)||x<0||x>1||y<0||y>1) throw new Exception("Posições: 0 a 100");
   if(out.put(key,new float[]{x,y})!=null) throw new Exception("Tecla duplicada: "+key);
  }
  return out;
 }
 @Override protected void onServiceConnected() { instance=this; reload(); }
 void reload() {
  SharedPreferences p=getSharedPreferences("mapper",0);
  target=p.getString("package","com.dts.freefireth");
  mouse=p.getBoolean("mouse",false);
  sensitivity=Float.parseFloat(p.getString("sensitivity","1"));
  try { points=parse(p.getString("maps","")); } catch(Exception e) { points.clear(); enabled=false; }
  configureMouse();
 }
 void toggle() { enabled=!enabled; configureMouse(); Toast.makeText(this,enabled?"Mapper ativo • F8 pausa":"Mapper pausado",0).show(); }
 boolean active() { return enabled && target.equals(foreground); }
 void configureMouse() {
  lastX=Float.NaN; lastY=Float.NaN; buttons=0;
  if(Build.VERSION.SDK_INT>=34) {
   AccessibilityServiceInfo info=getServiceInfo();
   if(info!=null) { info.setMotionEventSources(active()&&mouse?InputDevice.SOURCE_MOUSE:0); setServiceInfo(info); }
  }
 }
 @Override public void onAccessibilityEvent(AccessibilityEvent e) {
  if(e.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.getPackageName()!=null) {
   String next=e.getPackageName().toString();
   if(!next.equals(foreground)) { foreground=next; configureMouse(); }
  }
 }
 @Override protected boolean onKeyEvent(KeyEvent e) {
  if(e.getKeyCode()==KeyEvent.KEYCODE_F8) {
   if(e.getAction()==KeyEvent.ACTION_DOWN&&e.getRepeatCount()==0) toggle();
   return true;
  }
  if(!active()) return false;
  String k=KeyEvent.keyCodeToString(e.getKeyCode()).replace("KEYCODE_","");
  boolean wasd=Arrays.asList("W","A","S","D").contains(k);
  if(!(wasd?points.containsKey("JOY"):points.containsKey(k))) return false;
  if(e.getAction()==KeyEvent.ACTION_DOWN) {
   if(wasd) {
    float[] j=points.get("JOY");
    float dx=k.equals("A")?-.07f:k.equals("D")?.07f:0;
    float dy=k.equals("W")?-.12f:k.equals("S")?.12f:0;
    gesture(j[0],j[1],j[0]+dx,j[1]+dy,90);
   } else if(e.getRepeatCount()==0) tap(k);
  }
  return true;
 }
 void tap(String key) { float[] p=points.get(key); if(p!=null) gesture(p[0],p[1],p[0],p[1],40); }
 @Override public void onMotionEvent(MotionEvent e) {
  if(!active()||!mouse||!e.isFromSource(InputDevice.SOURCE_MOUSE)) return;
  int b=e.getButtonState();
  if((b&MotionEvent.BUTTON_PRIMARY)!=0&&(buttons&MotionEvent.BUTTON_PRIMARY)==0) tap("MOUSE1");
  if((b&MotionEvent.BUTTON_SECONDARY)!=0&&(buttons&MotionEvent.BUTTON_SECONDARY)==0) tap("MOUSE2");
  buttons=b;
  float x=e.getX(),y=e.getY();
  if((e.getActionMasked()==MotionEvent.ACTION_HOVER_MOVE||e.getActionMasked()==MotionEvent.ACTION_MOVE)&&!Float.isNaN(lastX)) {
   float[] look=points.get("LOOK");
   if(look!=null) {
    android.graphics.Rect bounds=((WindowManager)getSystemService(WINDOW_SERVICE)).getCurrentWindowMetrics().getBounds();
    float dx=(x-lastX)/Math.max(1,bounds.width())*sensitivity;
    float dy=(y-lastY)/Math.max(1,bounds.height())*sensitivity;
    if(Math.abs(dx)+Math.abs(dy)>.001f) gesture(look[0],look[1],look[0]+dx,look[1]+dy,35);
   }
  }
  lastX=x; lastY=y;
 }
 void gesture(float x,float y,float ex,float ey,int duration) {
  if(busy||!active()) return;
  android.graphics.Point size=new android.graphics.Point();
  WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  if(Build.VERSION.SDK_INT>=30) { android.graphics.Rect r=wm.getCurrentWindowMetrics().getBounds(); size.set(r.width(),r.height()); }
  else wm.getDefaultDisplay().getRealSize(size);
  Path path=new Path(); path.moveTo(clamp(x)*size.x,clamp(y)*size.y);
  if(x!=ex||y!=ey) path.lineTo(clamp(ex)*size.x,clamp(ey)*size.y);
  busy=true;
  boolean sent=dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,duration)).build(),new GestureResultCallback(){
   @Override public void onCompleted(GestureDescription g){busy=false;}
   @Override public void onCancelled(GestureDescription g){busy=false;}
  },null);
  if(!sent) busy=false;
 }
 float clamp(float v) {return Math.max(.001f,Math.min(.999f,v));}
 @Override public void onInterrupt() { enabled=false; configureMouse(); }
 @Override public void onDestroy() { instance=null; super.onDestroy(); }
}